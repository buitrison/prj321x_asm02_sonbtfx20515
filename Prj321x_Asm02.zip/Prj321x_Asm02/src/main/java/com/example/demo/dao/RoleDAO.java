package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Role;

public interface RoleDAO {
	public List<Role> getRoles();

}
